package com.example.personal_feed_service.infrastructure.http;

import com.example.personal_feed_service.application.usecase.GetPersonalizedFeedUseCase;
import com.example.personal_feed_service.domain.model.NewsArticle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/feed")
public class FeedController {

    @Autowired
    private GetPersonalizedFeedUseCase feedUseCase;

    @GetMapping("/{userId}")
    public List<NewsArticle> getPersonalizedFeed(@PathVariable Long userId,
                                                 @RequestParam(defaultValue = "10") int topN) {
        return feedUseCase.getFeed(userId, topN);
    }
}