package com.example.personal_feed_service.infrastructure.http;

import com.example.personal_feed_service.application.usecase.RecordInteractionUseCase;
import com.example.personal_feed_service.domain.model.UserActivity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/interaction")
public class InteractionController {

    @Autowired
    private RecordInteractionUseCase interactionUseCase;

    @PostMapping("/{userId}/{articleId}")
    public UserActivity record(@PathVariable Long userId,
                               @PathVariable Long articleId,
                               @RequestParam("type") String typeStr) {
        UserActivity.ActivityType type = UserActivity.ActivityType.valueOf(typeStr.toUpperCase());
        return interactionUseCase.record(userId, articleId, type);
    }
}