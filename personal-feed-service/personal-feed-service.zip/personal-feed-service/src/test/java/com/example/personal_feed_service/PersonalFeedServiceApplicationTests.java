package com.example.personal_feed_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalFeedServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
